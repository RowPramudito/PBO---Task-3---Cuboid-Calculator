package Ruang;

public class Balok {
    private int length, width, height;

    int getLeng() {return length;}
    int getWid() {return width;}
    int getHeig() {return height;}

    public Balok(int length, int width, int height) {
        this.length = length;
        this.width = width;
        this.height = height;
    }
}
