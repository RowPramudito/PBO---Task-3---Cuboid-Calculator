package Ruang;

public class HitungRuang {
    public HitungRuang() {}

    public double countVol(Balok x) {
        double volume = x.getLeng() * x.getWid() * x.getHeig();
        return volume;
    }

    public double countSqArea(Balok x) {
        double sqArea = 2 * ((x.getLeng()*x.getWid()) + (x.getLeng()*x.getHeig()) + (x.getWid()*x.getHeig()));
        return sqArea;
    }
}
