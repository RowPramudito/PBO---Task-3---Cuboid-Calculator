package Bidang;

public class PersegiPanjang {
    private int length, width;

    public int getLeng() {return length;}
    public int getWid() {return width;}

    public PersegiPanjang(int length, int width) {
        this.length = length;
        this.width = width;
    }
}
