package Bidang;

public class HitungBidang {
    public HitungBidang() {}

    public double countArea(PersegiPanjang x) {
        double area = x.getLeng() * x.getWid();
        return area;
    } 

    public double countCircum(PersegiPanjang x) {
        double circum = (x.getLeng() * 2) + (x.getWid() * 2);
        return circum;
    }
}
