package Main;

import javax.swing.*;
import Bidang.*;
import Ruang.*;

public class GUI extends JFrame {
    JPanel panel = new JPanel();

    private JTextField inputLength = new JTextField();
    private JTextField inputWidth =  new JTextField();
    private JTextField inputHeight = new JTextField();

    private JLabel resArea = new JLabel("");
    private JLabel resCircum = new JLabel("");
    private JLabel resVol = new JLabel("");
    private JLabel resSurface = new JLabel("");

    JButton submitButton = new JButton("Count");
    JButton resetButton = new JButton("Reset");

    GUI() {
        this.setSize(500,500);
        this.setDefaultCloseOperation(GUI.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.add(panel);

        panel.setLayout(null);

        JLabel programTitle = new JLabel("Cuboid Calculator");
        programTitle.setBounds(200,20,200,25);
        panel.add(programTitle);

        JLabel length = new JLabel("Length");
        length.setBounds(80,100,50,25);
        panel.add(length);

        inputLength.setBounds(150, 100, 180, 25);
        panel.add(inputLength);

        JLabel width = new JLabel("Width");
        width.setBounds(80,150,50,25);
        panel.add(width);

        inputWidth.setBounds(150,150,180,25);
        panel.add(inputWidth);

        JLabel height = new JLabel("Height");
        height.setBounds(80,200,50,25);
        panel.add(height);
        
        inputHeight.setBounds(150,200,180,25);
        panel.add(inputHeight);

        JLabel result = new JLabel("Result:");
        result.setBounds(150,250,100,25);
        panel.add(result);

        resArea.setBounds(80,275,400,25);
        panel.add(resArea);
        
        resCircum.setBounds(80,300,400,25);
        panel.add(resCircum);
        
        resVol.setBounds(80,325,400,25);
        panel.add(resVol);

        resSurface.setBounds(80,350,400,25);
        panel.add(resSurface);
        
        submitButton.setBounds(150,400,80,25);
        panel.add(submitButton);
        
        resetButton.setBounds(245,400,80,25);
        panel.add(resetButton);

        this.setVisible(true);
    }

    public String getInputLength() {return inputLength.getText();}
    public String getInputWidth() {return inputWidth.getText();}
    public String getInputHeight() {return inputHeight.getText();}

    public void setResArea(HitungBidang hitungBidang, PersegiPanjang persegiPanjang) {
        this.resArea.setText("Square area: " + hitungBidang.countArea(persegiPanjang));
    }
    public void setResCircum(HitungBidang hitungBidang, PersegiPanjang persegiPanjang) {
        this.resCircum.setText("Square Circumference: " + hitungBidang.countCircum(persegiPanjang));
    }
    public void setResSurface(HitungRuang hitungRuang, Balok balok) {
        this.resSurface.setText("Cube surface area: " + hitungRuang.countSqArea(balok));
    }
    public void setResVol(HitungRuang hitungRuang, Balok balok) {
        this.resVol.setText("Cube Volume: " + hitungRuang.countVol(balok));
    }

    public void resetInput() {
        this.inputLength.setText("");
        this.inputWidth.setText("");
        this.inputHeight.setText("");

        this.resArea.setText("");  
        this.resCircum.setText("");
        this.resSurface.setText(""); 
        this.resVol.setText("");
    } 
}
