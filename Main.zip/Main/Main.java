package Main;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import Bidang.*;
import Ruang.*;

public class Main {
    public static void main(String[] args) {
        GUI gui = new GUI();

        gui.submitButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                String x = gui.getInputLength();
                String y = gui.getInputWidth();
                String z = gui.getInputHeight();

                try {
                    int length = Integer.parseInt(x);
                    int width = Integer.parseInt(y);
                    int height = Integer.parseInt(z);
    
                    PersegiPanjang persegiPanjang = new PersegiPanjang(length, width);
                    Balok balok = new Balok(length, width, height);
        
                    HitungBidang hitungBidang = new HitungBidang();
                    HitungRuang hitungRuang = new HitungRuang();
    
                    gui.setResArea(hitungBidang, persegiPanjang);
                    gui.setResCircum(hitungBidang, persegiPanjang);
                    gui.setResSurface(hitungRuang, balok);
                    gui.setResVol(hitungRuang, balok);
                } 
                catch(Exception exc1) {
                    JOptionPane.showMessageDialog(null, exc1.getMessage());
                }
            }
        });

        gui.resetButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                gui.resetInput();
            }
            
        });
    }
}
